# FINIX Android App

Android-first starter app for the FINIX Body Recomposition & Diet experience.

## Included
- Dark black + orange UI
- Explore dashboard
- Body Recomposition plan
- 18-week navigation
- Daily meal screens
- Calories and macros
- Progress and Profile placeholders

## Build
Open this folder in Android Studio and run:
`./gradlew assembleDebug`

The generated APK will be under:
`app/build/outputs/apk/debug/`
