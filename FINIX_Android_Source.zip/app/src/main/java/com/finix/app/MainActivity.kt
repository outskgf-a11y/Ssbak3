package com.finix.app

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val orange = Color.rgb(255, 170, 0)
    private val black = Color.rgb(10, 10, 10)
    private val surface = Color.rgb(21, 21, 21)
    private val text = Color.rgb(245, 245, 245)
    private val muted = Color.rgb(146, 151, 163)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<TextView>(R.id.navHome).setOnClickListener { showHome() }
        findViewById<TextView>(R.id.navExplore).setOnClickListener { showExplore() }
        findViewById<TextView>(R.id.navProgress).setOnClickListener { showProgress() }
        findViewById<TextView>(R.id.navProfile).setOnClickListener { showProfile() }

        showExplore()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(black)
            setPadding(dp(20), dp(18), dp(20), dp(12))
        }
    }

    private fun title(s: String, size: Float = 30f): TextView =
        TextView(this).apply {
            text = s
            setTextColor(text)
            textSize = size
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(6), 0, dp(10))
        }

    private fun subtitle(s: String): TextView =
        TextView(this).apply {
            text = s
            setTextColor(muted)
            textSize = 15f
            setPadding(0, 0, 0, dp(18))
        }

    private fun card(label: String, detail: String, emoji: String, click: () -> Unit): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(18), dp(18), dp(18))
            background = getDrawable(R.drawable.bg_card)
            isClickable = true
            setOnClickListener { click() }

            addView(TextView(this@MainActivity).apply {
                text = emoji
                textSize = 32f
            })
            addView(TextView(this@MainActivity).apply {
                text = label
                textSize = 20f
                setTextColor(text)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            })
            addView(TextView(this@MainActivity).apply {
                text = detail
                textSize = 14f
                setTextColor(muted)
                setPadding(0, dp(5), 0, 0)
            })
        }
    }

    private fun showExplore() {
        val root = base()
        root.addView(title("Explore"))
        root.addView(subtitle("Choose a FINIX nutrition plan"))

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
        }

        list.addView(card("Body Recomposition", "18 weeks • Build muscle + reduce fat", "🔥") {
            showPlan()
        }, lp())

        list.addView(space(12))
        list.addView(card("Lean Mode", "1500 / 1750 / 2000 kcal options", "⚡") {
            toast("Lean Mode coming next")
        }, lp())

        list.addView(space(12))
        list.addView(card("Ultimate Shred", "Fat-loss focused nutrition plans", "💪") {
            toast("Ultimate Shred coming next")
        }, lp())

        list.addView(space(20))
        list.addView(title("Body Recomposition", 22f))
        list.addView(card("Non-Veg • 2000 kcal", "18 weeks • Chicken, eggs, dal & Indian foods", "🥩") {
            showPlan()
        }, lp())
        list.addView(space(12))
        list.addView(card("Veg • 2000 kcal", "18 weeks • Vegetarian meals", "🥗") {
            toast("Veg plan selected")
        }, lp())

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContent(root)
    }

    private fun showPlan() {
        val root = base()
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val back = TextView(this).apply {
            text = "‹"
            textSize = 40f
            setTextColor(orange)
            setOnClickListener { showExplore() }
        }
        top.addView(back, LinearLayout.LayoutParams(dp(45), dp(55)))
        top.addView(title("Non-Veg 2000Kcal", 25f), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(top)

        root.addView(subtitle("18 weeks • Body Recomposition"))

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val weeks = listOf(
            "Week 1–8" to "1,929 kcal/day",
            "Week 9–12" to "1,607 kcal/day",
            "Week 13" to "1,929 kcal/day",
            "Week 14–17" to "2,199 kcal/day",
            "Week 18" to "1,929 kcal/day"
        )

        weeks.forEachIndexed { index, pair ->
            list.addView(card(pair.first, pair.second, "📅") {
                showWeek(if (index == 1) 9 else index + 1, pair.second)
            }, lp())
            list.addView(space(12))
        }

        val start = TextView(this).apply {
            text = "START THIS PLAN"
            gravity = Gravity.CENTER
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(black)
            background = getDrawable(R.drawable.bg_button)
            setPadding(0, dp(15), 0, dp(15))
            setOnClickListener { toast("Plan started — Week 1") }
        }
        list.addView(start, lp())

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContent(root)
    }

    private fun showWeek(week: Int, calories: String) {
        val root = base()
        root.addView(title("Week $week", 28f))
        root.addView(subtitle("Daily target: $calories"))

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        val days = listOf("MONDAY","TUESDAY","WEDNESDAY","THURSDAY","FRIDAY","SATURDAY","SUNDAY")
        days.forEachIndexed { i, day ->
            list.addView(card("Day ${i + 1} • $day", calories, "🍽️") {
                showDay(day, calories)
            }, lp())
            list.addView(space(10))
        }

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContent(root)
    }

    private fun showDay(day: String, calories: String) {
        val root = base()
        root.addView(title(day, 30f))
        root.addView(subtitle(calories))

        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }

        list.addView(card("Breakfast", "425 kcal • Oats + skim milk + banana + almonds", "🥣") {}, lp())
        list.addView(space(10))
        list.addView(card("Lunch", "649 kcal • Rice + chicken + chana dal + salad + olive oil", "🍗") {}, lp())
        list.addView(space(10))
        list.addView(card("Dinner", "507 kcal • Whole-wheat roti + chicken + salad + olive oil", "🍽️") {}, lp())
        list.addView(space(10))
        list.addView(card("Before Workout", "297 kcal • Banana + skim milk + peanut butter", "⚡") {}, lp())
        list.addView(space(10))
        list.addView(card("After Workout", "139 kcal • Whey isolate + egg whites + water", "💪") {}, lp())
        list.addView(space(18))

        list.addView(TextView(this).apply {
            text = "Macros\nProtein 141.5 g   •   Fat 66 g   •   Carbs 183.9 g"
            textSize = 17f
            setTextColor(text)
            setPadding(dp(4), dp(12), dp(4), dp(20))
        })

        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContent(root)
    }

    private fun showHome() {
        val root = base()
        root.addView(title("FINIX"))
        root.addView(subtitle("Your body recomposition journey"))

        root.addView(card("Today's Target", "1,929 kcal • 141.5 g protein", "🔥") {
            showDay("MONDAY", "1,929 kcal")
        }, lp())
        root.addView(space(14))
        root.addView(card("Current Plan", "Non-Veg 2000 kcal • Week 1", "📅") {
            showPlan()
        }, lp())
        root.addView(space(14))
        root.addView(card("Progress", "Track your weight, measurements & photos", "📈") {
            showProgress()
        }, lp())
        setContent(root)
    }

    private fun showProgress() {
        val root = base()
        root.addView(title("Progress"))
        root.addView(subtitle("Your FINIX transformation"))

        root.addView(card("Weight", "Add your current weight", "⚖️") {})
        root.addView(space(12))
        root.addView(card("Measurements", "Waist • Chest • Arms • Hips", "📏") {})
        root.addView(space(12))
        root.addView(card("Progress Photos", "Front • Side • Back", "📸") {})
        setContent(root)
    }

    private fun showProfile() {
        val root = base()
        root.addView(title("Profile"))
        root.addView(subtitle("FINIX settings"))

        root.addView(card("Nutrition Target", "2000 kcal", "🎯") {})
        root.addView(space(12))
        root.addView(card("Diet Type", "Non-Vegetarian", "🥩") {})
        root.addView(space(12))
        root.addView(card("App Version", "FINIX 1.0", "⚙️") {})
        setContent(root)
    }

    private fun setContent(view: View) {
        findViewById<FrameLayout>(R.id.content).removeAllViews()
        findViewById<FrameLayout>(R.id.content).addView(view)
    }

    private fun lp() = LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT)

    private fun space(h: Int) = Space(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(h))
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
